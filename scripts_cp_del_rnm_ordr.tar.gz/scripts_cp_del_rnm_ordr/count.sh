count=$(find /HEP_DATA/Mostafa/H400_BLSSM_Bkg/FULL_HZZ4l_Bkg_Full/* -maxdepth 0 -type d | wc -l)
echo $count

